package com.web.movie.services;

import java.util.List;

import com.web.movie.entities.History;

public interface HistoryService {
	List <History> getAllHistory();
}
